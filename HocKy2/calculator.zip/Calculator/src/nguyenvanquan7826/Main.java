package nguyenvanquan7826;

/**
 * ----------------- @author nguyenvanquan7826 -----------------
 * ---------------nguyenvanquan7826.wordpress.com --------------
 */
public class Main {
	public static void main(String[] args) {
		new CalculatorGUI();
	}
}
